﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using Npgsql;
using Movies.Database;
using Movies.Models;

namespace Movies
{
    public partial class GenresWindow : Window
    {
        private int? selectedGenreId = null;

        public GenresWindow()
        {
            InitializeComponent();
            LoadGenres();
        }

        // Загрузка списка жанров
        private void LoadGenres()
        {
            var genres = new List<Genre>();

            using (var connection = DbConnection.GetConnection())
            {
                connection.Open();
                string query = "SELECT genreid, genrename FROM genres ORDER BY genrename";

                using (var cmd = new NpgsqlCommand(query, connection))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        genres.Add(new Genre
                        {
                            GenreId = reader.GetInt32(0),
                            GenreName = reader.GetString(1)
                        });
                    }
                }
            }

            genresGrid.ItemsSource = genres;
        }

        // Выбор строки
        private void genresGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (genresGrid.SelectedItem is Genre selected)
            {
                selectedGenreId = selected.GenreId;
                txtGenreName.Text = selected.GenreName;
            }
        }

        // Добавление жанра
        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtGenreName.Text))
            {
                MessageBox.Show("Введите название жанра.");
                return;
            }

            try
            {
                using (var connection = DbConnection.GetConnection())
                {
                    connection.Open();
                    string query = "INSERT INTO genres (genrename) VALUES (@name)";

                    using (var cmd = new NpgsqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("name", txtGenreName.Text.Trim());
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Жанр добавлен.");
                LoadGenres();
                ClearFields();
            }
            catch (PostgresException ex) when (ex.SqlState == "23505") 
            {
                MessageBox.Show("Такой жанр уже существует.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }

        // Изменение жанра
        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            if (selectedGenreId == null)
            {
                MessageBox.Show("Выберите жанр для изменения.");
                return;
            }

            if (string.IsNullOrWhiteSpace(txtGenreName.Text))
            {
                MessageBox.Show("Введите название жанра.");
                return;
            }

            try
            {
                using (var connection = DbConnection.GetConnection())
                {
                    connection.Open();
                    string query = "UPDATE genres SET genrename = @name WHERE genreid = @id";

                    using (var cmd = new NpgsqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("name", txtGenreName.Text.Trim());
                        cmd.Parameters.AddWithValue("id", selectedGenreId.Value);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Жанр обновлён.");
                LoadGenres();
                ClearFields();
            }
            catch (PostgresException ex) when (ex.SqlState == "23505")
            {
                MessageBox.Show("Такой жанр уже существует.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }

        // Удаление жанра
        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (selectedGenreId == null)
            {
                MessageBox.Show("Выберите жанр для удаления.");
                return;
            }

            if (MessageBox.Show("Удалить этот жанр?", "Подтверждение",
                MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
                return;

            try
            {
                using (var connection = DbConnection.GetConnection())
                {
                    connection.Open();

                    string checkQuery = @"
                        SELECT 
                            (SELECT COUNT(*) FROM movies WHERE genreid = @id) AS movie_count,
                            (SELECT COUNT(*) FROM userpreferences WHERE genreid = @id) AS pref_count";

                    long movieCount = 0, prefCount = 0;
                    using (var cmd = new NpgsqlCommand(checkQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("id", selectedGenreId.Value);
                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                movieCount = reader.GetInt64(0);
                                prefCount = reader.GetInt64(1);
                            }
                        }
                    }

                    if (movieCount > 0 || prefCount > 0)
                    {
                        MessageBox.Show(
                            $"Нельзя удалить жанр: он используется.\n" +
                            $"Фильмов: {movieCount}, предпочтений: {prefCount}.");
                        return;
                    }

                    string query = "DELETE FROM genres WHERE genreid = @id";
                    using (var cmd = new NpgsqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("id", selectedGenreId.Value);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Жанр удалён.");
                LoadGenres();
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }

        private void btnRefresh_Click(object sender, RoutedEventArgs e)
        {
            LoadGenres();
            ClearFields();
        }

        private void ClearFields()
        {
            selectedGenreId = null;
            txtGenreName.Clear();
            genresGrid.SelectedItem = null;
        }
    }
}