﻿using Movies.Database;
using System;
using System.Windows;
using Npgsql;

namespace Movies
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            TestConnection();
        }

        private void TestConnection()
        {
                using (var connection = DbConnection.GetConnection())
                {
                    connection.Open();
                }
         
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            string login = txtLogin.Text;
            string password = txtPassword.Password;

            try
            {
                using (var connection = DbConnection.GetConnection())
                {
                    connection.Open();

                    string query = @"
    SELECT a.role, a.userid 
    FROM account a 
    WHERE a.login = @login AND a.password = @password";

                    using (var cmd = new NpgsqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("login", login);
                        cmd.Parameters.AddWithValue("password", password);

                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                string role = reader.GetString(0);
                                int userId = reader.GetInt32(1); 

                                MoviesWindow moviesWindow = new MoviesWindow(role, userId);
                                moviesWindow.Show();
                                this.Close();
                            }
                            else
                            {
                                MessageBox.Show("Неверный логин или пароль");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
