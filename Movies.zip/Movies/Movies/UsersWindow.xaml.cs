﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using Npgsql;
using Movies.Database;
using Movies.Models;

namespace Movies
{
    public partial class UsersWindow : Window
    {
        private int? selectedAccountId = null; 

        public UsersWindow()
        {
            InitializeComponent();
            LoadUsers();
        }

        private void LoadUsers()
        {
            var users = new List<UserAccount>();

            using (var connection = DbConnection.GetConnection())
            {
                connection.Open();
                string query = @"
                    SELECT a.accountid, a.login, a.password, a.role, 
                           u.userid, u.fullname, u.email
                    FROM account a
                    LEFT JOIN users u ON a.userid = u.userid
                    ORDER BY a.accountid";

                using (var cmd = new NpgsqlCommand(query, connection))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        users.Add(new UserAccount
                        {
                            AccountId = reader.GetInt32(0),
                            Login = reader.GetString(1),
                            Password = reader.GetString(2),
                            Role = reader.GetString(3),
                            UserId = reader.IsDBNull(4) ? 0 : reader.GetInt32(4),
                            FullName = reader.IsDBNull(5) ? "" : reader.GetString(5),
                            Email = reader.IsDBNull(6) ? "" : reader.GetString(6)
                        });
                    }
                }
            }

            usersGrid.ItemsSource = users;
        }

        private void usersGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (usersGrid.SelectedItem is UserAccount selected)
            {
                selectedAccountId = selected.AccountId;
                txtLogin.Text = selected.Login;
                txtPassword.Password = selected.Password;
                txtFullName.Text = selected.FullName;
                txtEmail.Text = selected.Email;

                foreach (ComboBoxItem item in cmbRole.Items)
                {
                    if (item.Content.ToString() == selected.Role)
                    {
                        cmbRole.SelectedItem = item;
                        break;
                    }
                }
            }
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtLogin.Text) || string.IsNullOrWhiteSpace(txtPassword.Password))
            {
                MessageBox.Show("Логин и пароль обязательны.");
                return;
            }

            string role = (cmbRole.SelectedItem as ComboBoxItem)?.Content.ToString() ?? "User";

            using (var connection = DbConnection.GetConnection())
            {
                connection.Open();
                using (var transaction = connection.BeginTransaction())
                {
                    try
                    {
                        int userId = 0;
                        if (!string.IsNullOrWhiteSpace(txtFullName.Text) || !string.IsNullOrWhiteSpace(txtEmail.Text))
                        {
                            string queryUser = @"
                                INSERT INTO users (fullname, email) 
                                VALUES (@fullname, @email) RETURNING userid";

                            using (var cmd = new NpgsqlCommand(queryUser, connection, transaction))
                            {
                                cmd.Parameters.AddWithValue("fullname", txtFullName.Text);
                                cmd.Parameters.AddWithValue("email", txtEmail.Text);
                                userId = (int)cmd.ExecuteScalar();
                            }
                        }

                        string queryAccount = @"
                            INSERT INTO account (login, password, role, userid) 
                            VALUES (@login, @password, @role, @userid)";

                        using (var cmd = new NpgsqlCommand(queryAccount, connection, transaction))
                        {
                            cmd.Parameters.AddWithValue("login", txtLogin.Text);
                            cmd.Parameters.AddWithValue("password", txtPassword.Password);
                            cmd.Parameters.AddWithValue("role", role);
                            cmd.Parameters.AddWithValue("userid", userId > 0 ? userId : (object)DBNull.Value);
                            cmd.ExecuteNonQuery();
                        }

                        transaction.Commit();
                        MessageBox.Show("Пользователь добавлен.");
                        LoadUsers();
                        ClearFields();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        MessageBox.Show("Ошибка: " + ex.Message);
                    }
                }
            }
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            if (selectedAccountId == null)
            {
                MessageBox.Show("Выберите запись для изменения.");
                return;
            }

            string role = (cmbRole.SelectedItem as ComboBoxItem)?.Content.ToString() ?? "User";

            using (var connection = DbConnection.GetConnection())
            {
                connection.Open();
                using (var transaction = connection.BeginTransaction())
                {
                    try
                    {
                        int userId = 0;
                        string queryGetUserId = "SELECT userid FROM account WHERE accountid = @id";
                        using (var cmd = new NpgsqlCommand(queryGetUserId, connection, transaction))
                        {
                            cmd.Parameters.AddWithValue("id", selectedAccountId.Value);
                            var result = cmd.ExecuteScalar();
                            if (result != null && result != DBNull.Value)
                                userId = (int)result;
                        }

                        string queryAccount = @"
                            UPDATE account 
                            SET login = @login, password = @password, role = @role 
                            WHERE accountid = @id";

                        using (var cmd = new NpgsqlCommand(queryAccount, connection, transaction))
                        {
                            cmd.Parameters.AddWithValue("login", txtLogin.Text);
                            cmd.Parameters.AddWithValue("password", txtPassword.Password);
                            cmd.Parameters.AddWithValue("role", role);
                            cmd.Parameters.AddWithValue("id", selectedAccountId.Value);
                            cmd.ExecuteNonQuery();
                        }

                        if (userId > 0)
                        {
                            string queryUser = @"
                                UPDATE users 
                                SET fullname = @fullname, email = @email 
                                WHERE userid = @userid";

                            using (var cmd = new NpgsqlCommand(queryUser, connection, transaction))
                            {
                                cmd.Parameters.AddWithValue("fullname", txtFullName.Text);
                                cmd.Parameters.AddWithValue("email", txtEmail.Text);
                                cmd.Parameters.AddWithValue("userid", userId);
                                cmd.ExecuteNonQuery();
                            }
                        }
                        else if (!string.IsNullOrWhiteSpace(txtFullName.Text))
                        {
                            string queryUser = @"
                                INSERT INTO users (fullname, email) 
                                VALUES (@fullname, @email) RETURNING userid";

                            using (var cmd = new NpgsqlCommand(queryUser, connection, transaction))
                            {
                                cmd.Parameters.AddWithValue("fullname", txtFullName.Text);
                                cmd.Parameters.AddWithValue("email", txtEmail.Text);
                                userId = (int)cmd.ExecuteScalar();
                            }

                            string queryLink = "UPDATE account SET userid = @userid WHERE accountid = @id";
                            using (var cmd = new NpgsqlCommand(queryLink, connection, transaction))
                            {
                                cmd.Parameters.AddWithValue("userid", userId);
                                cmd.Parameters.AddWithValue("id", selectedAccountId.Value);
                                cmd.ExecuteNonQuery();
                            }
                        }

                        transaction.Commit();
                        MessageBox.Show("Данные обновлены.");
                        LoadUsers();
                        ClearFields();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        MessageBox.Show("Ошибка: " + ex.Message);
                    }
                }
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (selectedAccountId == null)
            {
                MessageBox.Show("Выберите запись для удаления.");
                return;
            }

            if (MessageBox.Show("Удалить этого пользователя?", "Подтверждение",
                MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
                return;

            using (var connection = DbConnection.GetConnection())
            {
                connection.Open();
                using (var transaction = connection.BeginTransaction())
                {
                    try
                    {
                        int userId = 0;
                        string queryGet = "SELECT userid FROM account WHERE accountid = @id";
                        using (var cmd = new NpgsqlCommand(queryGet, connection, transaction))
                        {
                            cmd.Parameters.AddWithValue("id", selectedAccountId.Value);
                            var result = cmd.ExecuteScalar();
                            if (result != null && result != DBNull.Value)
                                userId = (int)result;
                        }

                        string queryAccount = "DELETE FROM account WHERE accountid = @id";
                        using (var cmd = new NpgsqlCommand(queryAccount, connection, transaction))
                        {
                            cmd.Parameters.AddWithValue("id", selectedAccountId.Value);
                            cmd.ExecuteNonQuery();
                        }

                        if (userId > 0)
                        {
                            string queryCheck = "SELECT COUNT(*) FROM account WHERE userid = @userid";
                            using (var cmd = new NpgsqlCommand(queryCheck, connection, transaction))
                            {
                                cmd.Parameters.AddWithValue("userid", userId);
                                long count = (long)cmd.ExecuteScalar();
                                if (count == 0)
                                {
                                    string queryDeleteUser = "DELETE FROM users WHERE userid = @userid";
                                    using (var cmd2 = new NpgsqlCommand(queryDeleteUser, connection, transaction))
                                    {
                                        cmd2.Parameters.AddWithValue("userid", userId);
                                        cmd2.ExecuteNonQuery();
                                    }
                                }
                            }
                        }

                        transaction.Commit();
                        MessageBox.Show("Пользователь удалён.");
                        LoadUsers();
                        ClearFields();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        MessageBox.Show("Ошибка: " + ex.Message);
                    }
                }
            }
        }

        private void btnRefresh_Click(object sender, RoutedEventArgs e)
        {
            LoadUsers();
            ClearFields();
        }

        private void ClearFields()
        {
            selectedAccountId = null;
            txtLogin.Clear();
            txtPassword.Clear();
            txtFullName.Clear();
            txtEmail.Clear();
            cmbRole.SelectedIndex = -1;
            usersGrid.SelectedItem = null;
        }
    }

    public class UserAccount
    {
        public int AccountId { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }
        public int UserId { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
    }
}