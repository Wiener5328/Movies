﻿using Movies.Database;
using Movies.Models;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace Movies
{
    public partial class MovieEditWindow : Window
    {
        private int? movieId = null; 

        public MovieEditWindow()
        {
            InitializeComponent();
            LoadGenres();
        }

        // Конструктор для редактирования
        public MovieEditWindow(Movie movie) : this()
        {
            movieId = movie.MovieId;
            Title = "Редактирование фильма";

            txtTitle.Text = movie.Title;
            txtAnnotation.Text = movie.Annotation;
            txtYear.Text = movie.ReleaseYear.ToString();

            // Устанавливаем рейтинг
            foreach (ComboBoxItem item in cmbRating.Items)
            {
                if (item.Content.ToString() == movie.Rating.ToString())
                {
                    cmbRating.SelectedItem = item;
                    break;
                }
            }

            // Устанавливаем жанр по имени
            if (cmbGenre.ItemsSource is List<Genre> genres)
            {
                // Ищем жанр по названию
                var selected = genres.Find(g => g.GenreName == movie.GenreName);
                if (selected != null)
                {
                    cmbGenre.SelectedItem = selected;
                }
            }
        }

        private void LoadGenres()
        {
            var genres = new List<Genre>();
            using (var connection = DbConnection.GetConnection())
            {
                connection.Open();
                string query = "SELECT genreid, genrename FROM genres ORDER BY genrename";
                using (var cmd = new NpgsqlCommand(query, connection))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        genres.Add(new Genre
                        {
                            GenreId = reader.GetInt32(0),
                            GenreName = reader.GetString(1)
                        });
                    }
                }
            }
            cmbGenre.ItemsSource = genres;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            // Валидация названия
            if (string.IsNullOrWhiteSpace(txtTitle.Text))
            {
                MessageBox.Show("Введите название фильма.");
                return;
            }

            // Валидация года
            if (!int.TryParse(txtYear.Text, out int year) || year < 1880 || year > 2100)
            {
                MessageBox.Show("Введите корректный год выпуска.");
                return;
            }

            // Валидация рейтинга 
            if (!(cmbRating.SelectedItem is ComboBoxItem ratingItem))
            {
                MessageBox.Show("Выберите рейтинг.");
                return;
            }

            // Валидация жанра 
            if (!(cmbGenre.SelectedItem is Genre selectedGenre))
            {
                MessageBox.Show("Выберите жанр.");
                return;
            }

            int rating = int.Parse(ratingItem.Content.ToString());

            try
            {
                using (var connection = DbConnection.GetConnection())
                {
                    connection.Open();

                    if (movieId == null)
                    {
                        // Добавление
                        string query = @"
                    INSERT INTO movies (title, annotation, releaseyear, rating, genreid)
                    VALUES (@title, @annotation, @year, @rating, @genreid)";
                        using (var cmd = new NpgsqlCommand(query, connection))
                        {
                            cmd.Parameters.AddWithValue("title", txtTitle.Text.Trim());
                            cmd.Parameters.AddWithValue("annotation", txtAnnotation.Text);
                            cmd.Parameters.AddWithValue("year", year);
                            cmd.Parameters.AddWithValue("rating", rating);
                            cmd.Parameters.AddWithValue("genreid", selectedGenre.GenreId);
                            cmd.ExecuteNonQuery();
                        }
                    }
                    else
                    {
                        // Редактирование
                        string query = @"
                    UPDATE movies 
                    SET title = @title, annotation = @annotation, 
                        releaseyear = @year, rating = @rating, genreid = @genreid
                    WHERE movieid = @id";
                        using (var cmd = new NpgsqlCommand(query, connection))
                        {
                            cmd.Parameters.AddWithValue("title", txtTitle.Text.Trim());
                            cmd.Parameters.AddWithValue("annotation", txtAnnotation.Text);
                            cmd.Parameters.AddWithValue("year", year);
                            cmd.Parameters.AddWithValue("rating", rating);
                            cmd.Parameters.AddWithValue("genreid", selectedGenre.GenreId);
                            cmd.Parameters.AddWithValue("id", movieId.Value);
                            cmd.ExecuteNonQuery();
                        }
                    }
                }

                DialogResult = true; 
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}