﻿using Npgsql;

namespace Movies.Database
{
    public static class DbConnection
    {
        private static string connectionString =
            "Host=localhost;Port=5432;Database=Movies;Username=postgres;Password=0079585";

        public static NpgsqlConnection GetConnection()
        {
            return new NpgsqlConnection(connectionString);
        }
    }
}