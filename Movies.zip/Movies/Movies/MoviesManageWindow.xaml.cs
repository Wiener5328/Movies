﻿using System;
using System.Collections.Generic;
using System.Windows;
using Npgsql;
using Movies.Database;
using Movies.Models;

namespace Movies
{
    public partial class MoviesManageWindow : Window
    {
        public MoviesManageWindow()
        {
            InitializeComponent();
            LoadMovies();
        }

        private void LoadMovies()
        {
            var movies = new List<Movie>();
            using (var connection = DbConnection.GetConnection())
            {
                connection.Open();
                string query = @"
                    SELECT m.movieid, m.title, m.annotation, m.releaseyear, m.rating, g.genrename 
                    FROM movies m 
                    JOIN genres g ON m.genreid = g.genreid 
                    ORDER BY m.title";
                using (var cmd = new NpgsqlCommand(query, connection))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        movies.Add(new Movie
                        {
                            MovieId = reader.GetInt32(0),
                            Title = reader.GetString(1),
                            Annotation = reader.GetString(2),
                            ReleaseYear = reader.GetInt32(3),
                            Rating = reader.GetInt32(4),
                            GenreName = reader.GetString(5)
                        });
                    }
                }
            }
            moviesGrid.ItemsSource = movies;
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            var editWindow = new MovieEditWindow();
            editWindow.Owner = this;
            if (editWindow.ShowDialog() == true) LoadMovies();
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            if (!(moviesGrid.SelectedItem is Movie selected))
            {
                MessageBox.Show("Выберите фильм для изменения.");
                return;
            }

            var editWindow = new MovieEditWindow(selected);
            editWindow.Owner = this;
            if (editWindow.ShowDialog() == true) LoadMovies();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (!(moviesGrid.SelectedItem is Movie selected))
            {
                MessageBox.Show("Выберите фильм для удаления.");
                return;
            }

            if (MessageBox.Show($"Удалить фильм \"{selected.Title}\"?", "Подтверждение",
                MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
                return;

            try
            {
                using (var connection = DbConnection.GetConnection())
                {
                    connection.Open();
                    string query = "DELETE FROM movies WHERE movieid = @id";
                    using (var cmd = new NpgsqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("id", selected.MovieId);
                        cmd.ExecuteNonQuery();
                    }
                }
                LoadMovies();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }

        private void btnRefresh_Click(object sender, RoutedEventArgs e)
        {
            LoadMovies();
        }
    }
}