﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Movies.Database;
using Movies.Models;
using Npgsql;

namespace Movies
{
    public partial class MoviesWindow : Window
    {
        private string role;
        private int currentUserId; 

        public MoviesWindow(string userRole, int userId) 
        {
            InitializeComponent();
            role = userRole;
            currentUserId = userId;

            if (role != "Admin")
            {
                btnUsers.Visibility = Visibility.Collapsed;
                btnGenres.Visibility = Visibility.Collapsed;
                btnManageMovies.Visibility = Visibility.Collapsed;
            }

            LoadGenres();
            LoadMovies();
        }
        private void btnUsers_Click(object sender, RoutedEventArgs e)
        {
            UsersWindow usersWindow = new UsersWindow();
            usersWindow.Owner = this;
            usersWindow.ShowDialog(); 
        }

        private void btnGenres_Click(object sender, RoutedEventArgs e)
        {
            GenresWindow genresWindow = new GenresWindow();
            genresWindow.Owner = this;
            genresWindow.ShowDialog();

            LoadGenres();
            LoadMovies();
        }
        private void LoadMovies()
        {
            List<Movie> movies = new List<Movie>();

            using (var connection = DbConnection.GetConnection())
            {
                connection.Open();

                string query =
                @"SELECT
            m.movieid,
            m.title,
            m.annotation,
            m.releaseyear,
            m.rating,
            g.genrename
        FROM movies m
        JOIN genres g
            ON m.genreid = g.genreid";

                using (var cmd = new NpgsqlCommand(query, connection))
                {
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            movies.Add(new Movie
                            {
                                MovieId = reader.GetInt32(0),
                                Title = reader.GetString(1),
                                Annotation = reader.GetString(2),
                                ReleaseYear = reader.GetInt32(3),
                                Rating = reader.GetInt32(4),
                                GenreName = reader.GetString(5)
                            });
                        }
                    }
                }
            }

            moviesGrid.ItemsSource = movies;
        }
        private void btnAllMovies_Click(object sender, RoutedEventArgs e)
        {
            LoadMovies();
        }
        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            SearchMovies();
        }
        private void SearchMovies()
        {
            List<Movie> movies = new List<Movie>();

            using (var connection = DbConnection.GetConnection())
            {
                connection.Open();

                string query =
                @"SELECT
            m.movieid,
            m.title,
            m.annotation,
            m.releaseyear,
            m.rating,
            g.genrename
        FROM movies m
        JOIN genres g
            ON m.genreid = g.genreid
        WHERE LOWER(m.title)
            LIKE LOWER(@title)";

                using (var cmd = new NpgsqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue(
                        "title",
                        "%" + txtSearch.Text + "%");

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            movies.Add(new Movie()
                            {
                                MovieId = reader.GetInt32(0),
                                Title = reader.GetString(1),
                                Annotation = reader.GetString(2),
                                ReleaseYear = reader.GetInt32(3),
                                Rating = reader.GetInt32(4),
                                GenreName = reader.GetString(5)
                            });
                        }
                    }
                }
            }

            moviesGrid.ItemsSource = movies;
        }

        private void LoadGenres()
        {
            var genres = new List<Genre>();

            genres.Add(new Genre { GenreId = 0, GenreName = "Все жанры" });

            using (var connection = DbConnection.GetConnection())
            {
                connection.Open();
                string query = "SELECT genreid, genrename FROM genres ORDER BY genrename";
                using (var cmd = new NpgsqlCommand(query, connection))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        genres.Add(new Genre
                        {
                            GenreId = reader.GetInt32(0),
                            GenreName = reader.GetString(1)
                        });
                    }
                }
            }

            cmbGenres.ItemsSource = genres;
            cmbGenres.DisplayMemberPath = "GenreName";
            cmbGenres.SelectedValuePath = "GenreId";

            cmbGenres.SelectedIndex = 0;
        }
        private void cmbGenres_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cmbGenres.SelectedValue is int genreId)
            {
                if (genreId == 0)
                {
                    LoadMovies(); 
                }
                else
                {
                    LoadMoviesByGenre(genreId);
                }
            }
        }

        private void LoadMoviesByGenre(int genreId)
        {
            List<Movie> movies = new List<Movie>();
            using (var connection = DbConnection.GetConnection())
            {
                connection.Open();
                string query = @"
            SELECT m.movieid, m.title, m.annotation, m.releaseyear, m.rating, g.genrename 
            FROM movies m 
            JOIN genres g ON m.genreid = g.genreid 
            WHERE m.genreid = @genreId";

                using (var cmd = new NpgsqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("genreId", genreId);
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            movies.Add(new Movie
                            {
                                MovieId = reader.GetInt32(0),
                                Title = reader.GetString(1),
                                Annotation = reader.GetString(2),
                                ReleaseYear = reader.GetInt32(3),
                                Rating = reader.GetInt32(4),
                                GenreName = reader.GetString(5)
                            });
                        }
                    }
                }
            }
            moviesGrid.ItemsSource = movies;
        }
        private void cmbRating_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cmbRating.SelectedItem is ComboBoxItem selectedItem)
            {
                int ratingFilter = int.Parse(selectedItem.Tag.ToString());
                FilterMoviesByRating(ratingFilter);
            }
        }

        private void FilterMoviesByRating(int minRating)
        {
            if (cmbRating.SelectedIndex == 0)
            {
                LoadMovies();
                return;
            }

            List<Movie> movies = new List<Movie>();
            using (var connection = DbConnection.GetConnection())
            {
                connection.Open();
                string query = @"
            SELECT m.movieid, m.title, m.annotation, m.releaseyear, m.rating, g.genrename 
            FROM movies m 
            JOIN genres g ON m.genreid = g.genreid 
            WHERE m.rating = @rating";

                using (var cmd = new NpgsqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("rating", minRating);
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            movies.Add(new Movie
                            {
                                MovieId = reader.GetInt32(0),
                                Title = reader.GetString(1),
                                Annotation = reader.GetString(2),
                                ReleaseYear = reader.GetInt32(3),
                                Rating = reader.GetInt32(4),
                                GenreName = reader.GetString(5)
                            });
                        }
                    }
                }
            }
            moviesGrid.ItemsSource = movies;
        }
        
        private void btnLogout_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Выйти из аккаунта?", "Подтверждение",
                MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
                return;

            var loginWindow = new MainWindow();
            loginWindow.Show();
            this.Close();
        }
     

        private void btnMyMovies_Click(object sender, RoutedEventArgs e)
        {
            if (currentUserId == 0)
            {
                MessageBox.Show("Вы не авторизованы как пользователь — нечего подбирать.");
                return;
            }

            var movies = new List<Movie>();

            using (var connection = DbConnection.GetConnection())
            {
                connection.Open();

                string checkQuery = "SELECT COUNT(*) FROM userpreferences WHERE userid = @userid";
                long prefCount;
                using (var cmd = new NpgsqlCommand(checkQuery, connection))
                {
                    cmd.Parameters.AddWithValue("userid", currentUserId);
                    prefCount = (long)cmd.ExecuteScalar();
                }

                if (prefCount == 0)
                {
                    MessageBox.Show("У вас пока не выбраны любимые жанры.\n" +
                                    "Нажмите «Мои интересы», чтобы выбрать.");
                    return;
                }

                string query = @"
            SELECT DISTINCT m.movieid, m.title, m.annotation, m.releaseyear, 
                            m.rating, g.genrename
            FROM movies m
            JOIN genres g ON m.genreid = g.genreid
            JOIN userpreferences up ON g.genreid = up.genreid
            WHERE up.userid = @userid
            ORDER BY m.title";

                using (var cmd = new NpgsqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("userid", currentUserId);
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            movies.Add(new Movie
                            {
                                MovieId = reader.GetInt32(0),
                                Title = reader.GetString(1),
                                Annotation = reader.GetString(2),
                                ReleaseYear = reader.GetInt32(3),
                                Rating = reader.GetInt32(4),
                                GenreName = reader.GetString(5)
                            });
                        }
                    }
                }
            }

            moviesGrid.ItemsSource = movies;

            if (movies.Count == 0)
            {
                MessageBox.Show("В ваших любимых жанрах пока нет фильмов.");
            }
        }

        private void btnManageMovies_Click(object sender, RoutedEventArgs e)
        {
            var manageWindow = new MoviesManageWindow();
            manageWindow.Owner = this;
            manageWindow.ShowDialog();

            LoadMovies();
            LoadGenres();
        }
        private void btnPreferences_Click(object sender, RoutedEventArgs e)
        {
            var prefWindow = new PreferencesWindow(currentUserId);
            prefWindow.Owner = this;
            if (prefWindow.ShowDialog() == true)
            {
                MessageBox.Show("Интересы сохранены.");
            }
        }
    }
}
