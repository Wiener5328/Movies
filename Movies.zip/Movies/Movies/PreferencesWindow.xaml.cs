﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using Npgsql;
using Movies.Database;
using Movies.Models;

namespace Movies
{
    public partial class PreferencesWindow : Window
    {
        private int currentUserId;
        private List<Genre> allGenres = new List<Genre>();
        private HashSet<int> selectedGenreIds = new HashSet<int>();

        public PreferencesWindow(int userId)
        {
            InitializeComponent();
            currentUserId = userId;
            LoadGenresAndPreferences();
        }

        private void LoadGenresAndPreferences()
        {
            using (var connection = DbConnection.GetConnection())
            {
                connection.Open();

                string genreQuery = "SELECT genreid, genrename FROM genres ORDER BY genrename";
                using (var cmd = new NpgsqlCommand(genreQuery, connection))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        allGenres.Add(new Genre
                        {
                            GenreId = reader.GetInt32(0),
                            GenreName = reader.GetString(1)
                        });
                    }
                }

                string prefQuery = "SELECT genreid FROM userpreferences WHERE userid = @userid";
                using (var cmd = new NpgsqlCommand(prefQuery, connection))
                {
                    cmd.Parameters.AddWithValue("userid", currentUserId);
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            selectedGenreIds.Add(reader.GetInt32(0));
                        }
                    }
                }
            }

            genresPanel.Children.Clear();
            foreach (var genre in allGenres)
            {
                var cb = new CheckBox
                {
                    Content = genre.GenreName,
                    Tag = genre.GenreId,
                    Margin = new Thickness(0, 5, 0, 5),
                    FontSize = 13,
                    IsChecked = selectedGenreIds.Contains(genre.GenreId)
                };
                genresPanel.Children.Add(cb);
            }
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            var newGenreIds = new List<int>();
            foreach (var child in genresPanel.Children)
            {
                if (child is CheckBox cb && cb.IsChecked == true)
                {
                    newGenreIds.Add((int)cb.Tag);
                }
            }

            try
            {
                using (var connection = DbConnection.GetConnection())
                {
                    connection.Open();
                    using (var transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            string delQuery = "DELETE FROM userpreferences WHERE userid = @userid";
                            using (var cmd = new NpgsqlCommand(delQuery, connection, transaction))
                            {
                                cmd.Parameters.AddWithValue("userid", currentUserId);
                                cmd.ExecuteNonQuery();
                            }

                            string insQuery = @"
                                INSERT INTO userpreferences (userid, genreid) 
                                VALUES (@userid, @genreid)";
                            foreach (int genreId in newGenreIds)
                            {
                                using (var cmd = new NpgsqlCommand(insQuery, connection, transaction))
                                {
                                    cmd.Parameters.AddWithValue("userid", currentUserId);
                                    cmd.Parameters.AddWithValue("genreid", genreId);
                                    cmd.ExecuteNonQuery();
                                }
                            }

                            transaction.Commit();
                        }
                        catch
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }

                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}