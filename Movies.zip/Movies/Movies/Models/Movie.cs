﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Movies.Models
{
    public class Movie
    {
        public int MovieId { get; set; }

        public string Title { get; set; }

        public string Annotation { get; set; }

        public int ReleaseYear { get; set; }

        public int Rating { get; set; }

        public string GenreName { get; set; }
    }
}
